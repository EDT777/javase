package 集合类实现队列结构;

public interface Queue {
	//往栈中放数据，访到栈底部
		public Object pop();
		
		public void push(Object t);
		
}
